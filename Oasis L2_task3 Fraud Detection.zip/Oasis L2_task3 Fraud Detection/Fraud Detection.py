import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# -----------------------------
# Load Dataset
# -----------------------------

df = pd.read_csv("SampleSuperstore.csv")

print("="*60)
print("FIRST 5 ROWS")
print(df.head())

print("="*60)
print("DATASET INFO")
print(df.info())

print("="*60)
print("MISSING VALUES")
print(df.isnull().sum())

# -----------------------------
# Remove Missing Values
# -----------------------------

df.dropna(inplace=True)

# -----------------------------
# Remove Duplicate Rows
# -----------------------------

df.drop_duplicates(inplace=True)

print("\nDataset Shape :", df.shape)

# -----------------------------
# Descriptive Statistics
# -----------------------------

print("\nAverage Sales")
print(df["Sales"].mean())

print("\nAverage Quantity")
print(df["Quantity"].mean())

print("\nAverage Profit")
print(df["Profit"].mean())

print("\nSummary Statistics")
print(df[["Sales","Quantity","Discount","Profit"]].describe())

# -----------------------------
# Feature Selection
# -----------------------------

features = df[["Sales","Quantity","Profit"]]

# -----------------------------
# Standardization
# -----------------------------

scaler = StandardScaler()

scaled_features = scaler.fit_transform(features)

# -----------------------------
# Elbow Method
# -----------------------------

wcss = []

for i in range(1,11):

    kmeans = KMeans(
        n_clusters=i,
        random_state=42,
        n_init=10
    )

    kmeans.fit(scaled_features)

    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8,5))

plt.plot(range(1,11),wcss,marker='o')

plt.title("Elbow Method")

plt.xlabel("Number of Clusters")

plt.ylabel("WCSS")

plt.grid(True)

plt.show()

# -----------------------------
# Apply KMeans
# -----------------------------

kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

df["Cluster"] = kmeans.fit_predict(scaled_features)

print("\nCluster Added Successfully")

# -----------------------------
# Scatter Plot 1
# -----------------------------

plt.figure(figsize=(8,6))

sns.scatterplot(
    x="Sales",
    y="Profit",
    hue="Cluster",
    palette="Set1",
    data=df
)

plt.title("Sales vs Profit")

plt.show()

# -----------------------------
# Scatter Plot 2
# -----------------------------

plt.figure(figsize=(8,6))

sns.scatterplot(
    x="Sales",
    y="Quantity",
    hue="Cluster",
    palette="Set2",
    data=df
)

plt.title("Sales vs Quantity")

plt.show()

# -----------------------------
# Cluster Profile
# -----------------------------

profile = df.groupby("Cluster")[["Sales","Quantity","Profit"]].mean()

print("\n")
print("="*60)
print("CLUSTER PROFILE")
print(profile)

# -----------------------------
# Customer Count
# -----------------------------

cluster_count = df["Cluster"].value_counts().sort_index()

plt.figure(figsize=(7,5))

cluster_count.plot(kind="bar",color="skyblue")

plt.title("Number of Records in Each Cluster")

plt.xlabel("Cluster")

plt.ylabel("Count")

plt.show()

# -----------------------------
# Marketing Insights
# -----------------------------

print("\n")
print("="*60)
print("MARKETING INSIGHTS")
print("="*60)

for cluster in profile.index:

    sales = profile.loc[cluster,"Sales"]

    profit = profile.loc[cluster,"Profit"]

    quantity = profile.loc[cluster,"Quantity"]

    print(f"\nCluster {cluster}")

    print("------------------------")

    print(f"Average Sales    : {sales:.2f}")

    print(f"Average Quantity : {quantity:.2f}")

    print(f"Average Profit   : {profit:.2f}")

    if sales > profile["Sales"].mean():

        print("Recommendation : Premium offers, loyalty rewards and exclusive discounts.")

    elif profit < 0:

        print("Recommendation : Reduce discount and improve pricing strategy.")

    else:

        print("Recommendation : Promote products using seasonal offers.")

# -----------------------------
# Save Result
# -----------------------------

df.to_csv("Customer_Segmentation_Result.csv",index=False)

print("\nResult Saved Successfully!")

print("File Name : Customer_Segmentation_Result.csv")